#ifndef COMMON_H
#define COMMON_H

void die(char *issue);

#endif /* COMMON_H */
